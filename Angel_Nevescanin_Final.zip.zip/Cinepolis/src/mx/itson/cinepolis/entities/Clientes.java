/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mx.itson.cinepolis.entities;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import mx.itson.cinepolis.persistence.MySQLConnection;

/**
 *
 * @author angel
 */
public class Clientes {
    
    private int idCliente;
    private String nombreCliente;
    private String telefonoCliente;
    private String correoCliente;

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getTelefonoCliente() {
        return telefonoCliente;
    }

    public void setTelefonoCliente(String telefonoCliente) {
        this.telefonoCliente = telefonoCliente;
    }

    public String getCorreoCliente() {
        return correoCliente;
    }

    public void setCorreoCliente(String correoCliente) {
        this.correoCliente = correoCliente;
    }
    
    //Metodo para poder obtener todos los datos de cliente
    public static List<Clientes> getAll(String filtro){
    List<Clientes> clientes = new ArrayList<>();
    try{
    Connection conexion = MySQLConnection.get();
    PreparedStatement statement = conexion.prepareStatement("SELECT * FROM clientes WHERE nombre LIKE ?");
    statement.setString(1, "%" + filtro + "%");
    ResultSet resultSet = statement.executeQuery();
    
    
    while(resultSet.next()){
    Clientes o = new Clientes();
    o.setIdCliente(resultSet.getInt(1));
    o.setNombreCliente(resultSet.getString(2));
    o.setTelefonoCliente(resultSet.getString(3));
    o.setCorreoCliente(resultSet.getString(4));
    clientes.add(o);
    }
    }catch(SQLException ex){
        
    }
    return clientes;
    }
    
    //Metodo para guardar un nuevo cliente
    public boolean save(String nombre, String telefono, String correo){
    boolean result = false;
    try{
    Connection conexion = MySQLConnection.get();
    String query = "INSERT INTO clientes (nombre, telefono, correo) VALUES (?, ?, ?)";
    PreparedStatement statement = conexion.prepareStatement(query);
    statement.setString(1, nombre);
    statement.setString(2, telefono);
    statement.setString(3, correo);
    statement.execute();
    
    result = statement.getUpdateCount() == 1;
    
    conexion.close();
    }catch(Exception ex){
    System.err.println("Error: " + ex.getMessage());
    
    }
    return result;
    }

    //Metodo para actualizar o editar un cliente existenten
    public boolean update(int id, String nombre, String telefono, String correo){
    boolean result = false;
    try{
    Connection conexion = MySQLConnection.get();
    String query = "UPDATE clientes SET nombre = ?, telefono = ?, correo = ?, WHERE id = ?";
    PreparedStatement statement = conexion.prepareStatement(query);
    statement.setString(1, nombre);
    statement.setString(2, telefono);
    statement.setString(3, correo);
    statement.setInt(4, id);
    statement.execute();
    
    result = statement.getUpdateCount() == 1;
    
    conexion.close();
    }catch(Exception ex){
    System.err.println("Error: " + ex.getMessage());
    
    }
    return result;
    }
    
    //Metodo para eliminar un cliente ya existenten.
    public boolean delete(int id){
    boolean result = false;
    try{
    Connection conexion = MySQLConnection.get();
    String query = "DELETE FROM clientes WHERE id = ?";
    PreparedStatement statement = conexion.prepareStatement(query);
    
    statement.setInt(1, id);
    statement.execute();
    
    result = statement.getUpdateCount() == 1;
    
    conexion.close();
    }catch(Exception ex){
    System.err.println("Error: " + ex.getMessage());
    
    }
    return result;
    }
    
}
