                                                                                                                                                                                                                                                                                                                           /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mx.itson.cinepolis.entities;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import mx.itson.cinepolis.persistence.MySQLConnection;

/**
 *
 * @author angel
 */
public class Peliculas {
    
    private int idPeliculas;
    private String nombrePelicula;
    private String generoPelicual;

    public int getIdPeliculas() {
        return idPeliculas;
    }

    public void setIdPeliculas(int idPeliculas) {
        this.idPeliculas = idPeliculas;
    }

    public String getNombrePelicula() {
        return nombrePelicula;
    }

    public void setNombrePelicula(String nombrePelicula) {
        this.nombrePelicula = nombrePelicula;
    }

    public String getGeneroPelicual() {
        return generoPelicual;
    }

    public void setGeneroPelicual(String generoPelicual) {
        this.generoPelicual = generoPelicual;
    }
    
    
    //Mostrar todas las peliculas
    public static List<Peliculas> getAll(String filtro){
    List<Peliculas> peliculas = new ArrayList<>();
    try{
    Connection conexion = MySQLConnection.get();
    PreparedStatement statement = conexion.prepareStatement("SELECT * FROM peliculas WHERE name LIKE ?");
    statement.setString(1, "%" + filtro + "%");
    ResultSet resultSet = statement.executeQuery();
    
    
    while(resultSet.next()){
    Peliculas o = new Peliculas();
    o.setIdPeliculas(resultSet.getInt(1));
    o.setNombrePelicula(resultSet.getString(2));
    o.setGeneroPelicual(resultSet.getString(3));
    peliculas.add(o);
    }
    }catch(SQLException ex){
        
    }
    return peliculas;
    }
    
    //Guardar nueva pelicula
    public boolean save(String nombre, String genero){
    boolean result = false;
    try{
    Connection conexion = MySQLConnection.get();
    String query = "INSERT INTO peliculas (nombre, genero) VALUES (?, ?, ?)";
    PreparedStatement statement = conexion.prepareStatement(query);
    statement.setString(1, nombre);
    statement.setString(2, genero);
    statement.execute();
    
    result = statement.getUpdateCount() == 1;
    
    conexion.close();
    }catch(Exception ex){
    System.err.println("Error: " + ex.getMessage());
    
    }
    return result;
    }

    //Actulizar o editar pelicula
    public boolean update(int id, String nombre, String genero){
    boolean result = false;
    try{
    Connection conexion = MySQLConnection.get();
    String query = "UPDATE officer SET nombre = ?, genero = ?, WHERE id = ?";
    PreparedStatement statement = conexion.prepareStatement(query);
    statement.setString(1, nombre);
    statement.setString(2, genero);
    statement.setInt(3, id);
    statement.execute();
    
    result = statement.getUpdateCount() == 1;
    
    conexion.close();
    }catch(Exception ex){
    System.err.println("Error: " + ex.getMessage());
    
    }
    return result;
    }
    
    //Eliminar pelicula existente
    public boolean delete(int id){
    boolean result = false;
    try{
    Connection conexion = MySQLConnection.get();
    String query = "DELETE FROM officer WHERE id = ?";
    PreparedStatement statement = conexion.prepareStatement(query);
    
    statement.setInt(1, id);
    statement.execute();
    
    result = statement.getUpdateCount() == 1;
    
    conexion.close();
    }catch(Exception ex){
    System.err.println("Error: " + ex.getMessage());
    
    }
    return result;
    }
    
}
