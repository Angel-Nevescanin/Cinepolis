/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mx.itson.cinepolis.entities;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import mx.itson.cinepolis.persistence.MySQLConnection;

/**
 *
 * @author angel
 */
public class Empleados {
    
    private int idEmpleado;
    private String nombreEmpleado;
    private String telefonoEmpleado;
    private String puestoEmpleado;

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public void setNombreEmpleado(String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }

    public String getTelefonoEmpleado() {
        return telefonoEmpleado;
    }

    public void setTelefonoEmpleado(String telefonoEmpleado) {
        this.telefonoEmpleado = telefonoEmpleado;
    }

    public String getPuestoEmpleado() {
        return puestoEmpleado;
    }

    public void setPuestoEmpleado(String puestoEmpleado) {
        this.puestoEmpleado = puestoEmpleado;
    }
    
    //Metodo para obtener todos los Empleados
    public static List<Empleados> getAll(String filtro){
    List<Empleados> empleados = new ArrayList<>();
    try{
    Connection conexion = MySQLConnection.get();
    PreparedStatement statement = conexion.prepareStatement("SELECT * FROM empleados WHERE nombre LIKE ?");
    statement.setString(1, "%" + filtro + "%");
    ResultSet resultSet = statement.executeQuery();
    
    
    while(resultSet.next()){
    Empleados o = new Empleados();
    o.setIdEmpleado(resultSet.getInt(1));
    o.setNombreEmpleado(resultSet.getString(2));
    o.setTelefonoEmpleado(resultSet.getString(3));
    o.setPuestoEmpleado(resultSet.getString(4));
    empleados.add(o);
    }
    }catch(SQLException ex){
        
    }
    return empleados;
    }
    
    //Metodo para guardar un nuevo Empleado
    public boolean save(String nombre, String telefono, String puesto){
    boolean result = false;
    try{
    Connection conexion = MySQLConnection.get();
    String query = "INSERT INTO empleados (nombre, telefono, puesto) VALUES (?, ?, ?, ?)";
    PreparedStatement statement = conexion.prepareStatement(query);
    statement.setString(1, nombre);
    statement.setString(2, telefono);
    statement.setString(3, puesto);
    statement.execute();
    
    result = statement.getUpdateCount() == 1;
    
    conexion.close();
    }catch(Exception ex){
    System.err.println("Error: " + ex.getMessage());
    
    }
    return result;
    }

    //Metodo para actulizar o editar un usuario existente
    public boolean update(int id, String nombre, String telefono, String puesto){
    boolean result = false;
    try{
    Connection conexion = MySQLConnection.get();
    String query = "UPDATE empleados SET nombre = ?, telefono = ?, puesto = ?, WHERE id = ?";
    PreparedStatement statement = conexion.prepareStatement(query);
    statement.setString(1, nombre);
    statement.setString(2, telefono);
    statement.setString(3, puesto);
    statement.setInt(4, id);
    statement.execute();
    
    result = statement.getUpdateCount() == 1;
    
    conexion.close();
    }catch(Exception ex){
    System.err.println("Error: " + ex.getMessage());
    
    }
    return result;
    }
    
    //Metodo para eliminar un Empleado existente
    public boolean delete(int id){
    boolean result = false;
    try{
    Connection conexion = MySQLConnection.get();
    String query = "DELETE FROM empleados WHERE id = ?";
    PreparedStatement statement = conexion.prepareStatement(query);
    
    statement.setInt(1, id);
    statement.execute();
    
    result = statement.getUpdateCount() == 1;
    
    conexion.close();
    }catch(Exception ex){
    System.err.println("Error: " + ex.getMessage());
    
    }
    return result;
    }
    
}
